const COOUD_CONFIG = {
  checkoutUrl: "https://go.centerpag.com/PPU38CQB1K2",
};
